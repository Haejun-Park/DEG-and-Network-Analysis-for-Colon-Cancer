#low <- read.csv("E:/20180829/positive_hub_network/exist/hub_exist_in_low.csv")
#high <- read.csv("E:/20180829/positive_hub_network/exist/hub_exist_in_high.csv")

#ID.low <- as.character(low[,1])
#ID.high <-as.character(high[,1])

#match.index <- match(ID.low, ID.high)

#high_data <- high[match.index,]

#file_name_combined_data =paste("E:/20180829/positive_hub_network/exist/sortbynegative_positive_data.csv", sep="")
#write.table(high_data ,row.names=FALSE,col.names=TRUE, file=file_name_combined_data ,sep=",")
rm(list=ls())

library(glmnet)
library(igraph)
library(NetSwan)

high_grade_colon_mRNA <- read.csv("E:/20180907/clinical/high_grade_colon_mRNA.csv", row.names = 1)
low_grade_colon_mRNA <- read.csv("E:/20180907/clinical/low_grade_colon_mRNA.csv", row.names = 1)

## transformation
high_grade_colon_mRNA_1 <- log2(high_grade_colon_mRNA+1)
low_grade_colon_mRNA_1 <- log2(low_grade_colon_mRNA+1)

Samples_mean<-apply(high_grade_colon_mRNA_1,2,mean)   #Standardize the data
Samples_sd<-apply(high_grade_colon_mRNA_1,2,sd)
for( i in 1:length(Samples_mean) )
{
  high_grade_colon_mRNA_1[ ,i]<-(high_grade_colon_mRNA_1[ ,i]-Samples_mean[i])/Samples_sd[i]
}

Samples_mean<-apply(low_grade_colon_mRNA_1,2,mean)   #Standardize the data
Samples_sd<-apply(low_grade_colon_mRNA_1,2,sd)
for( i in 1:length(Samples_mean) )
{
  low_grade_colon_mRNA_1[ ,i]<-(low_grade_colon_mRNA_1[ ,i]-Samples_mean[i])/Samples_sd[i]
}

low_grade_colon_mRNA_standardize <- low_grade_colon_mRNA_1
high_grade_colon_mRNA_standardize <- high_grade_colon_mRNA_1
#write.csv(low_grade_colon_mRNA_standardize, "C:/Users/mingming/Desktop/coloncancer/low_grade_colon_mRNA_standardize.csv")
#write.csv(high_grade_colon_mRNA_standardize, "C:/Users/mingming/Desktop/coloncancer/high_grade_colon_mRNA_standardize.csv")

high_list <- as.data.frame(read.csv("E:/20180907/clinical/network/exist/high_list_name.csv"))
high_list_name <- colnames(high_list)
high_grade_colon_mRNA_standardize <- subset(high_grade_colon_mRNA_standardize, select=high_list_name)
low_grade_colon_mRNA_standardize <- subset(low_grade_colon_mRNA_standardize,select=high_list_name)


#high_grade_colon_mRNA_standardize <- high_grade_colon_mRNA_standardize[,c("PCNP","C5orf41","TCF4","HEG1","SECISBP2L","TPI1P3","VIM","CLIP3","GNB4","MSRB3","FERMT2","LOC100132247","ZNF638","ATP8B2","BOC","CCDC80","LOC200030","MGP","ASXL2","CNRIP1","MLL2","RASSF2",
                                                                         # "SLC22A17","MATR3","ASH1L","BNC2","LY6G6D","PPIAL4G","APBB1","HSPG2","IL6ST","MCC","BMPR2","POLR2I","ROMO1","TIMP2","ZEB1","ETS1","GEFT","MAP3K2","PDCD10","RAB8B","RIF1","SPAST","SSB")]
#low_grade_colon_mRNA_standardize <- low_grade_colon_mRNA_standardize[,c("PCNP","C5orf41","TCF4","HEG1","SECISBP2L","TPI1P3","VIM","CLIP3","GNB4","MSRB3","FERMT2","LOC100132247","ZNF638","ATP8B2","BOC","CCDC80","LOC200030","MGP","ASXL2","CNRIP1","MLL2","RASSF2",
                                                                        #"SLC22A17","MATR3","ASH1L","BNC2","LY6G6D","PPIAL4G","APBB1","HSPG2","IL6ST","MCC","BMPR2","POLR2I","ROMO1","TIMP2","ZEB1","ETS1","GEFT","MAP3K2","PDCD10","RAB8B","RIF1","SPAST","SSB")]

########### network estimation 1 ##########
Sample_size <- 0.5*(dim(low_grade_colon_mRNA_standardize)[1]+dim(high_grade_colon_mRNA_standardize)[1])
nV <- dim(low_grade_colon_mRNA_standardize)[2]

ALPHA<-0.1
penalty_lambda<-round(2/Sample_size^0.5 *qnorm(ALPHA/2/nV^2, mean = 0, sd = 1, lower.tail = FALSE),5)
penalty_lambda_2<-penalty_lambda/2

##low grade
low_grade_colon_mRNA_standardize <- as.matrix(low_grade_colon_mRNA_standardize)

result_table <- matrix(NA,nrow=1,ncol=3)
colnames(result_table) <- c("Y_gene","X_gene","coef")

for(index in c(1:nV))
{  
  yy<-low_grade_colon_mRNA_standardize[,index]                   # Decide yy (child) and xx (parents) in the LASSO type penalized LR
  xx<-low_grade_colon_mRNA_standardize[,-index]
  
  y_node<-colnames(low_grade_colon_mRNA_standardize)[index] 
  x_node<-colnames(low_grade_colon_mRNA_standardize)[-index]   
  
  glmnet_fit<-glmnet(xx, yy,family=c("gaussian"),lambda=penalty_lambda_2)
  inter_coef_list<-coef(glmnet_fit)
  coef_list<-inter_coef_list[-1]
  
  temp_TF <- coef_list!=0
  selected_coef_list <- coef_list[temp_TF]
  selected_x_node <- x_node[temp_TF]
  
  if( length(selected_x_node)!=0 )
  { 
    temp_result_table <- cbind(y_node,selected_x_node,selected_coef_list) 
    result_table <- rbind(result_table,temp_result_table)
  }
}   

result_table_low_grade <- result_table[-1,]


# high grade
#high_grade_colon_mRNA_standardize <- as.matrix(high_grade_colon_mRNA_standardize)

#result_table <- matrix(NA,nrow=1,ncol=3)
#colnames(result_table) <- c("Y_gene","X_gene","coef")

#for(index in c(1:nV))
#{  
#  yy<-high_grade_colon_mRNA_standardize[,index]                   # Decide yy (child) and xx (parents) in the LASSO type penalized LR
#  xx<-high_grade_colon_mRNA_standardize[,-index]
  
#  y_node<-colnames(high_grade_colon_mRNA_standardize)[index] 
#  x_node<-colnames(high_grade_colon_mRNA_standardize)[-index]   
  
#  glmnet_fit<-glmnet(xx, yy,family=c("gaussian"),lambda=penalty_lambda_2)
#  inter_coef_list<-coef(glmnet_fit)
#  coef_list<-inter_coef_list[-1]
  
#  temp_TF <- coef_list!=0
#  selected_coef_list <- coef_list[temp_TF]
#  selected_x_node <- x_node[temp_TF]
  
#  if( length(selected_x_node)!=0 )
#  { 
#    temp_result_table <- cbind(y_node,selected_x_node,selected_coef_list) 
#    result_table <- rbind(result_table,temp_result_table)
#  }
  
#}    

#result_table_high_grade <- result_table[-1,]

#write.csv(result_table_high_grade, "E:/DEG/result_table_high_grade.csv")
write.csv(result_table_low_grade, "E:/20180907/clinical/network/negative_hub_network_sortposi/result_table_low_grade_lambda2_0.34027.csv")


########### network estimation 2 : lambda*0.5 ##########
Sample_size <- 0.5*(dim(low_grade_colon_mRNA_standardize)[1]+dim(high_grade_colon_mRNA_standardize)[1])
nV <- dim(low_grade_colon_mRNA_standardize)[2]

ALPHA<-0.1
penalty_lambda<-round(2/Sample_size^0.5 *qnorm(ALPHA/2/nV^2, mean = 0, sd = 1, lower.tail = FALSE),5)
penalty_lambda_2<-penalty_lambda/2
penalty_lambda_3<-penalty_lambda_2/2

# low grade
low_grade_colon_mRNA_standardize <- as.matrix(low_grade_colon_mRNA_standardize)

result_table <- matrix(NA,nrow=1,ncol=3)
colnames(result_table) <- c("Y_gene","X_gene","coef")

for(index in c(1:nV))
{  
  yy<-low_grade_colon_mRNA_standardize[,index]                   # Decide yy (child) and xx (parents) in the LASSO type penalized LR
  xx<-low_grade_colon_mRNA_standardize[,-index]
  
  y_node<-colnames(low_grade_colon_mRNA_standardize)[index] 
  x_node<-colnames(low_grade_colon_mRNA_standardize)[-index]   
  
  glmnet_fit<-glmnet(xx, yy,family=c("gaussian"),lambda=penalty_lambda_2)
  inter_coef_list<-coef(glmnet_fit)
  coef_list<-inter_coef_list[-1]
  
  temp_TF <- coef_list!=0
  selected_coef_list <- coef_list[temp_TF]
  selected_x_node <- x_node[temp_TF]
  
  if( length(selected_x_node)!=0 )
  { 
    temp_result_table <- cbind(y_node,selected_x_node,selected_coef_list) 
    result_table <- rbind(result_table,temp_result_table)
  }
}   

result_table_low_grade_lambda3 <- result_table[-1,]


# high grade
high_grade_colon_mRNA_standardize <- as.matrix(high_grade_colon_mRNA_standardize)

result_table <- matrix(NA,nrow=1,ncol=3)
colnames(result_table) <- c("Y_gene","X_gene","coef")

for(index in c(1:nV))
{  
  yy<-high_grade_colon_mRNA_standardize[,index]                   # Decide yy (child) and xx (parents) in the LASSO type penalized LR
  xx<-high_grade_colon_mRNA_standardize[,-index]
  
  y_node<-colnames(high_grade_colon_mRNA_standardize)[index] 
  x_node<-colnames(high_grade_colon_mRNA_standardize)[-index]   
  
  glmnet_fit<-glmnet(xx, yy,family=c("gaussian"),lambda=penalty_lambda_3)
  inter_coef_list<-coef(glmnet_fit)
  coef_list<-inter_coef_list[-1]
  
  temp_TF <- coef_list!=0
  selected_coef_list <- coef_list[temp_TF]
  selected_x_node <- x_node[temp_TF]
  
  if( length(selected_x_node)!=0 )
  { 
    temp_result_table <- cbind(y_node,selected_x_node,selected_coef_list) 
    result_table <- rbind(result_table,temp_result_table)
  }
  
}   

result_table_high_grade_lambda2 <- result_table[-1,]

write.csv(result_table_high_grade_lambda2, "C:/Users/mingming/Desktop/coloncancer/result_table_high_grade_lambda2.csv")
write.csv(result_table_low_grade_lambda3, "E:/DEG/result_table_low_grade_labmda4.csv")


########### network estimation 3 : lambda*0.25 ##########
Sample_size <- 0.5*(dim(low_grade_colon_mRNA_standardize)[1]+dim(high_grade_colon_mRNA_standardize)[1])
nV <- dim(low_grade_colon_mRNA_standardize)[2]

ALPHA<-0.1
penalty_lambda<-round(2/Sample_size^0.5 *qnorm(ALPHA/2/nV^2, mean = 0, sd = 1, lower.tail = FALSE),5)
penalty_lambda_2<-penalty_lambda/2
penalty_lambda_3<-penalty_lambda_2/2
penalty_lambda_4<-penalty_lambda_3/2

# low grade
low_grade_colon_mRNA_standardize <- as.matrix(low_grade_colon_mRNA_standardize)

result_table <- matrix(NA,nrow=1,ncol=3)
colnames(result_table) <- c("Y_gene","X_gene","coef")

for(index in c(1:nV))
{  
  yy<-low_grade_colon_mRNA_standardize[,index]                   # Decide yy (child) and xx (parents) in the LASSO type penalized LR
  xx<-low_grade_colon_mRNA_standardize[,-index]
  
  y_node<-colnames(low_grade_colon_mRNA_standardize)[index] 
  x_node<-colnames(low_grade_colon_mRNA_standardize)[-index]   
  
  glmnet_fit<-glmnet(xx, yy,family=c("gaussian"),lambda=penalty_lambda_4)
  inter_coef_list<-coef(glmnet_fit)
  coef_list<-inter_coef_list[-1]
  
  temp_TF <- coef_list!=0
  selected_coef_list <- coef_list[temp_TF]
  selected_x_node <- x_node[temp_TF]
  
  if( length(selected_x_node)!=0 )
  { 
    temp_result_table <- cbind(y_node,selected_x_node,selected_coef_list) 
    result_table <- rbind(result_table,temp_result_table)
  }
}   

result_table_low_grade_lambda4 <- result_table[-1,]


# high grade
high_grade_colon_mRNA_standardize <- as.matrix(high_grade_colon_mRNA_standardize)

result_table <- matrix(NA,nrow=1,ncol=3)
colnames(result_table) <- c("Y_gene","X_gene","coef")

for(index in c(1:nV))
{  
  yy<-high_grade_colon_mRNA_standardize[,index]                   # Decide yy (child) and xx (parents) in the LASSO type penalized LR
  xx<-high_grade_colon_mRNA_standardize[,-index]
  
  y_node<-colnames(high_grade_colon_mRNA_standardize)[index] 
  x_node<-colnames(high_grade_colon_mRNA_standardize)[-index]   
  
  glmnet_fit<-glmnet(xx, yy,family=c("gaussian"),lambda=penalty_lambda_4)
  inter_coef_list<-coef(glmnet_fit)
  coef_list<-inter_coef_list[-1]
  
  temp_TF <- coef_list!=0
  selected_coef_list <- coef_list[temp_TF]
  selected_x_node <- x_node[temp_TF]
  
  if( length(selected_x_node)!=0 )
  { 
    temp_result_table <- cbind(y_node,selected_x_node,selected_coef_list) 
    result_table <- rbind(result_table,temp_result_table)
  }
  
}   

result_table_high_grade_lambda4 <- result_table[-1,]

write.csv(result_table_high_grade_lambda4, "C:/Users/mingming/Desktop/coloncancer/result_table_high_grade_lambda4.csv")
write.csv(result_table_low_grade_lambda4, "C:/Users/mingming/Desktop/coloncancer/result_table_low_grade_labmda4.csv")

