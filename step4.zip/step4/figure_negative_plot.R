#####negative
###������Ʈ 

rm(list=ls())
library(readxl)
library(network)
library(sqldf)

name_index <- c( "supp2" )
normal_lambda <- c( 0.31431 )

high_list <- as.data.frame(read.csv("E:/20180907/network/exist/low_grade_93.csv"))

file_name=paste("E:/20180907/network/negative_hub_network_sortnega/result_table_low_grade_lambda2_0.31431.csv")
result_table<-as.matrix(read.table(file_name, header=TRUE, sep=",")) 


b <- as.vector(unique(rbind(as.matrix(unique(result_table[,1])), as.matrix(unique(result_table[,2])))))
c <- length(b) 
true_c<-matrix(rep(0, c*c), c, c)

colnames(true_c) <- b
rownames(true_c) <- b

node_info <- as.data.frame(b)
colnames(node_info) <- c("name")
node_info <- sqldf('SELECT a.name, b.type
                   FROM node_info a
                   LEFT JOIN high_list b USING(name)')

for(j in 1:dim(result_table)[1])
{
  true_c[result_table[j,1], result_table[j,2]] <- result_table[j,3]
}

true_X<-true_c
true_X[true_X!=0]<-1

d<-as.numeric(result_table[,3])


aa1 <- network(true_X)


file_name=paste("E:/20180907/network/negative_hub_network_sortnega/figure2_negative_",normal_lambda,".png", sep="")
png(filename=file_name, height=1000, width=1000, bg="white")
coord <- plot(aa1,displaylabels=TRUE,
              boxed.labels=FALSE,
              arrowhead.cex=0,
              label.cex=1.3, #character expansion factor for label text,
              pad=0.25,
              label.pos=10,
              edge.lwd=d*3.5,
              vertex.cex=2, #expansion factor for vertices
              vertex.col =  ifelse((is.na(node_info$type)),"white",
                                   ifelse(node_info$type == "positive", "light pink","light green")),
              mode ="fruchtermanreingold",  # "kamadakawai",  #"circle", #"fruchtermanreingold", 
              cex.main=1.5)

dev.off()

###positive
###������Ʈ 

#rm(list=ls())
library(readxl)
library(network)
library(sqldf)

name_index <- c( "supp2" )
normal_lambda <- c( 0.31431 )

high_list1 <- as.data.frame(read.csv("E:/20180907/network/exist/low_grade_93.csv"))

file_name1=paste("E:/20180907/network/positive_hub_network_sortnega/result_table_high_grade_lambda2_0.31431.csv")
result_table1<-as.matrix(read.table(file_name1, header=TRUE, sep=",")) 


b1 <- as.vector(unique(rbind(as.matrix(unique(result_table1[,1])), as.matrix(unique(result_table1[,2])))))
c1 <- length(b1) 
true_c1<-matrix(rep(0, c1*c1), c1, c1)

colnames(true_c1) <- b1
rownames(true_c1) <- b1

node_info1 <- as.data.frame(b1)
colnames(node_info1) <- c("name")
node_info1 <- sqldf('SELECT a.name, b.type
                     FROM node_info1 a
                     LEFT JOIN high_list1 b USING(name)')

for(j in 1:dim(result_table1)[1])
{
  true_c1[result_table1[j,1], result_table1[j,2]] <- result_table1[j,3]
}

true_X1<-true_c1
true_X1[true_X1!=0]<-1

d1<-as.numeric(result_table1[,3])


aa2 <- network(true_X1)


file_name=paste("E:/20180907/network/positive_hub_network_sortnega/figure2_postivie_",normal_lambda,".png", sep="")
png(filename=file_name, height=1000, width=1000, bg="white")
plot(aa2,coord=coord,displaylabels=TRUE,
     boxed.labels=FALSE,
     arrowhead.cex=0,
     label.cex=1.3, #character expansion factor for label text,
     pad=0.25,
     label.pos=10,
     edge.lwd=d*3.5,
     vertex.cex=2, #expansion factor for vertices
     vertex.col =  ifelse((is.na(node_info$type)),"white",
                          ifelse(node_info$type == "positive", "light pink","light green")),
     mode ="fruchtermanreingold",  # "kamadakawai",  #"circle", #"fruchtermanreingold", 
     cex.main=1.5)

dev.off()



#########################################################

##table6 network plot
rm(list=ls())
library(readxl)
library(network)
library(sqldf)

name_index <- c( "table6" )
normal_lambda <- c( 0.31431 )

file_name=paste("E:/20180810/positive_hub_network/positive_hub_network/result_table_high_grade_lambda2_0.31431.csv")
result_table<-as.matrix(read.table(file_name, header=TRUE, sep=","))

file_name=paste("E:/20180810/positive_hub_network/positive_hub_network/hub_exist_high_grade_lambda2_0.31431.csv")
hub_gene <- as.data.frame(read.table(file_name, header=TRUE, sep=","))

hub_gene$degree <- as.numeric(hub_gene$degree)
hub_gene <- hub_gene[c(order(-hub_gene$degree)),]
rownames(hub_gene) <- NULL

for(i in hub_gene){
  result_table_c <- result_table[result_table[,1] %in% i | result_table[,2] %in% i,]
  result_table_c
  b <- as.vector(unique(rbind(as.matrix(unique(result_table_c[,1])), as.matrix(unique(result_table_c[,2])))))
  c <- length(b) 
  true_c<-matrix(rep(0, c*c), c, c)
  
  colnames(true_c) <- b
  rownames(true_c) <- b

  for(j in 1:dim(result_table_c)[1])
  {
    true_c[result_table_c[j,1], result_table_c[j,2]] <- result_table_c[j,3]
  }
  
  true_X<-true_c
  true_X[true_X!=0]<-1
  
  d<-as.numeric(result_table_c[,3])
  

  aa1 <- network(true_X)
  
  
  file_name=paste("E:/20180810/positive_hub_network/positive_hub_network/table6_",normal_lambda,i,".png", sep="")
  png(filename=file_name, height=1000, width=1000, bg="white")
  plot(aa1,displaylabels=TRUE,
                         boxed.labels=FALSE,
                         arrowhead.cex=0,
                         label.cex=2, #character expansion factor for label text,
                         pad=0.25,
                         label.pos=10,
                         edge.lwd=d*3.5,
                         vertex.cex=3, #expansion factor for vertices
                         vertex.col = "yellow",
                         mode ="fruchtermanreingold",  # "kamadakawai",  #"circle", #"fruchtermanreingold", 
                         cex.main=5)
  dev.off()
}

file_name_true_D=paste("D:/Gene/Gene_FAM19A5_BNC_SDPC_case1_0.1.csv")
true_D_short<-as.matrix(read.table(file_name_true_D, header=TRUE, sep=","))
true_D<-matrix(rep(0,41*41), 41,41)
colnames(true_D) <- c("cg06409673_FAM19A5","cg09209679_FAM19A5","cg11019791_FAM19A5","cg14894848_FAM19A5",true_D_short[,2])
rownames(true_D) <- c("cg06409673_FAM19A5","cg09209679_FAM19A5","cg11019791_FAM19A5","cg14894848_FAM19A5",true_D_short[,2])

for(i in 1:dim(true_D_short)[1])
{
  true_D[true_D_short[i,1],true_D_short[i,2]]<-true_D_short[i,3]
}

true_X<-true_D
true_X[true_X!=0]<-1

library(network)

v<-as.numeric(true_D_short[,3])
v

bb1 <- network(true_X)
plot(bb1, coord = coordinate_nodes, displaylabels=TRUE,
     boxed.labels=FALSE,
     arrowhead.cex=0,
     label.cex=0.8,
     pad=0.25,
     label.pos=10,
     edge.lwd=b*3.5,
     vertex.col = "yellow",
     mode ="fruchtermanreingold",  # "kamadakawai",  #"circle", #"fruchtermanreingold", 
     cex.main=1.7)


# MDD_IN_MDD
file_name_true_B=paste("D:/Gene/cg/cg_FAM19A5_MDD_case1_0.05.csv")
true_B_short<-as.matrix(read.table(file_name_true_B, header=TRUE, sep=","))
true_B<-matrix(rep(0,92*92), 92,92)
colnames(true_B) <- c("cg00332378","cg03964091","cg06409673","cg09209679","cg11019791","cg13192640","cg14894848","cg26243759",true_B_short[,2])
rownames(true_B) <- c("cg00332378","cg03964091","cg06409673","cg09209679","cg11019791","cg13192640","cg14894848","cg26243759",true_B_short[,2])

for(i in 1:dim(true_B_short)[1])
{
  true_B[true_B_short[i,1],true_B_short[i,2]]<-true_B_short[i,3]
}

true_Y<-true_B
true_Y[true_Y!=0]<-1

library(network)

c<-as.numeric(true_B_short[,3])
c

aa2 <- network(true_Y)
coordinate_nodes2 <- plot(aa2,displaylabels=TRUE,
                         boxed.labels=FALSE,
                         arrowhead.cex=0,
                         label.cex=0.8,
                         pad=0.25,
                         label.pos=10,
                         edge.lwd=c*3.5,
                         vertex.col = "yellow",
                         mode ="fruchtermanreingold",  # "kamadakawai",  #"circle", #"fruchtermanreingold", 
                         cex.main=1.7)

file_name_true_C=paste("D:/Gene/Gene_FAM19A5_MDD_case1_0.05.csv")
true_C_short<-as.matrix(read.table(file_name_true_C, header=TRUE, sep=","))
true_C<-matrix(rep(0,92*92), 92,92)
colnames(true_C) <- c("cg00332378_FAM19A5","cg03964091_FAM19A5","cg06409673_FAM19A5","cg09209679_FAM19A5","cg11019791_FAM19A5","cg13192640_FAM19A5","cg14894848_FAM19A5","cg26243759_FAM19A5",true_C_short[,2])
rownames(true_C) <- c("cg00332378_FAM19A5","cg03964091_FAM19A5","cg06409673_FAM19A5","cg09209679_FAM19A5","cg11019791_FAM19A5","cg13192640_FAM19A5","cg14894848_FAM19A5","cg26243759_FAM19A5",true_C_short[,2])

for(i in 1:dim(true_C_short)[1])
{
  true_C[true_C_short[i,1],true_C_short[i,2]]<-true_C_short[i,3]
}

true_W<-true_C
true_W[true_W!=0]<-1

library(network)

f<-as.numeric(true_C_short[,3])
f

bb2 <- network(true_W)
plot(bb2,coord = coordinate_nodes2, displaylabels=TRUE,
     boxed.labels=FALSE,
     arrowhead.cex=0,
     label.cex=0.8,
     pad=0.25,
     label.pos=10,
     edge.lwd=c*3.5,
     vertex.col = "yellow",
     mode ="fruchtermanreingold",  # "kamadakawai",  #"circle", #"fruchtermanreingold", 
     cex.main=1.7)

################################# case2 : BNC_SDPC vs BPD ################################## 
# BNC_SDPC_IN_BPD
file_name_true_c=paste("D:/Gene/cg/cg_FAM19A5_BNC_SDPC_case2_0.1.csv")
true_c_short<-as.matrix(read.table(file_name_true_c, header=TRUE, sep=","))
true_c<-matrix(rep(0,41*41), 41,41)
colnames(true_c) <- c("cg06409673","cg09209679","cg11019791","cg14894848",true_c_short[,2])
rownames(true_c) <- c("cg06409673","cg09209679","cg11019791","cg14894848",true_c_short[,2])

for(i in 1:dim(true_c_short)[1])
{
  true_c[true_c_short[i,1],true_c_short[i,2]]<-true_c_short[i,3]
}

true_X<-true_c
true_X[true_X!=0]<-1

library(network)

d<-as.numeric(true_c_short[,3])
d

aa3 <- network(true_X)
coordinate_nodes3 <- plot(aa3,displaylabels=TRUE,
     boxed.labels=FALSE,
     arrowhead.cex=0,
     label.cex=0.8,
     pad=0.25,
     label.pos=10,
     edge.lwd=d*3.5,
     vertex.col = "yellow",
     mode ="fruchtermanreingold",  # "kamadakawai",  #"circle", #"fruchtermanreingold", 
     cex.main=1.7)

file_name_true_G=paste("D:/Gene/Gene_FAM19A5_BNC_SDPC_case2_0.1.csv")
true_G_short<-as.matrix(read.table(file_name_true_G, header=TRUE, sep=","))
true_G<-matrix(rep(0,41*41), 41,41)
colnames(true_G) <- c("cg06409673_FAM19A5","cg09209679_FAM19A5","cg11019791_FAM19A5","cg14894848_FAM19A5",true_G_short[,2])
rownames(true_G) <- c("cg06409673_FAM19A5","cg09209679_FAM19A5","cg11019791_FAM19A5","cg14894848_FAM19A5",true_G_short[,2])

for(i in 1:dim(true_G_short)[1])
{
  true_G[true_G_short[i,1],true_G_short[i,2]]<-true_G_short[i,3]
}

true_V<-true_G
true_V[true_V!=0]<-1

library(network)

t<-as.numeric(true_G_short[,3])
t

bb3 <- network(true_V)
plot(bb3,coord = coordinate_nodes3,displaylabels=TRUE,
     boxed.labels=FALSE,
     arrowhead.cex=0,
     label.cex=0.8,
     pad=0.25,
     label.pos=10,
     edge.lwd=d*3.5,
     vertex.col = "yellow",
     mode ="fruchtermanreingold",  # "kamadakawai",  #"circle", #"fruchtermanreingold", 
     cex.main=1.7)

# BPD_IN_BPD
file_name_true_d=paste("D:/Gene/cg/cg_FAM19A5_BPD_case2_0.1.csv")
true_d_short<-as.matrix(read.table(file_name_true_d, header=TRUE, sep=","))
true_d<-matrix(rep(0,32*32),32,32)
colnames(true_d) <- c("cg00332378","cg03964091","cg06409673","cg09209679","cg11019791","cg14894848",true_d_short[,2])
rownames(true_d) <- c("cg00332378","cg03964091","cg06409673","cg09209679","cg11019791","cg14894848",true_d_short[,2])

for(i in 1:dim(true_d_short)[1])
{
  true_d[true_d_short[i,1],true_d_short[i,2]]<-true_d_short[i,3]
}

true_Z<-true_d
true_Z[true_Z!=0]<-1

library(network)

e<-as.numeric(true_d_short[,3])
e

aa4 <- network(true_Z)
coordinate_nodes4 <- plot(aa4,displaylabels=TRUE,
     boxed.labels=FALSE,
     arrowhead.cex=0,
     label.cex=0.8,
     pad=0.25,
     label.pos=10,
     edge.lwd=e*3.5,
     vertex.col = "yellow",
    #vertex.cex = 3,
     mode ="fruchtermanreingold",  # "kamadakawai",  #"circle", #"fruchtermanreingold", 
     cex.main=1.7)

file_name_true_E=paste("D:/Gene/Gene_FAM19A5_BPD_case2_0.1.csv")
true_E_short<-as.matrix(read.table(file_name_true_E, header=TRUE, sep=","))
true_E<-matrix(rep(0,32*32),32,32)
colnames(true_E) <- c("cg00332378_FAM19A5","cg03964091_FAM19A5","cg06409673_FAM19A5","cg09209679_FAM19A5","cg11019791_FAM19A5","cg14894848_FAM19A5",true_E_short[,2])
rownames(true_E) <- c("cg00332378_FAM19A5","cg03964091_FAM19A5","cg06409673_FAM19A5","cg09209679_FAM19A5","cg11019791_FAM19A5","cg14894848_FAM19A5",true_E_short[,2])

for(i in 1:dim(true_E_short)[1])
{
  true_E[true_E_short[i,1],true_E_short[i,2]]<-true_E_short[i,3]
}

true_W<-true_E
true_W[true_W!=0]<-1

library(network)

g<-as.numeric(true_E_short[,3])
g

bb4 <- network(true_W)
plot(bb4,coord = coordinate_nodes4, displaylabels=TRUE,
     boxed.labels=FALSE,
     arrowhead.cex=0,
     label.cex=0.8,
     pad=0.25,
     label.pos=10,
     edge.lwd=e*3.5,
     vertex.col = "yellow",
     #vertex.cex = 3,
     mode ="fruchtermanreingold",  # "kamadakawai",  #"circle", #"fruchtermanreingold", 
     cex.main=1.7)
