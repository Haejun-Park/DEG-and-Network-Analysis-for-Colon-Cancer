rm(list=ls())
library(glmnet)
library(igraph)
library(NetSwan)

high_grade_colon_mRNA <- read.csv("E:/20180907/clinical/high_grade_colon_mRNA.csv", row.names = 1)
low_grade_colon_mRNA <- read.csv("E:/20180907/clinical/low_grade_colon_mRNA.csv", row.names = 1)

## transformation
high_grade_colon_mRNA_1 <- log2(high_grade_colon_mRNA+1)
low_grade_colon_mRNA_1 <- log2(low_grade_colon_mRNA+1)

Samples_mean<-apply(high_grade_colon_mRNA_1,2,mean)   #Standardize the data
Samples_sd<-apply(high_grade_colon_mRNA_1,2,sd)
for( i in 1:length(Samples_mean) )
{
  high_grade_colon_mRNA_1[ ,i]<-(high_grade_colon_mRNA_1[ ,i]-Samples_mean[i])/Samples_sd[i]
}

Samples_mean<-apply(low_grade_colon_mRNA_1,2,mean)   #Standardize the data
Samples_sd<-apply(low_grade_colon_mRNA_1,2,sd)
for( i in 1:length(Samples_mean) )
{
  low_grade_colon_mRNA_1[ ,i]<-(low_grade_colon_mRNA_1[ ,i]-Samples_mean[i])/Samples_sd[i]
}

low_grade_colon_mRNA_standardize <- low_grade_colon_mRNA_1
high_grade_colon_mRNA_standardize <- high_grade_colon_mRNA_1
#write.csv(low_grade_colon_mRNA_standardize, "C:/Users/mingming/Desktop/coloncancer/low_grade_colon_mRNA_standardize.csv")
#write.csv(high_grade_colon_mRNA_standardize, "C:/Users/mingming/Desktop/coloncancer/high_grade_colon_mRNA_standardize.csv")

low_list <- as.data.frame(read.csv("E:/20180907/clinical/network/exist/low_list_name.csv"))
low_list_name <- colnames(low_list)
high_grade_colon_mRNA_standardize <- subset(high_grade_colon_mRNA_standardize, select=low_list_name)
low_grade_colon_mRNA_standardize <- subset(low_grade_colon_mRNA_standardize,select=low_list_name)

#high_grade_colon_mRNA_standardize <- high_grade_colon_mRNA_standardize[,c("ZEB1","PCNP","CCDC80","ZNF638","BOC","AHSA2","PIKFYVE","C1S","OR7E37P","XPO1","AFF4","ZEB2","LY6G6D","SSB","VPS26A","SUMO1","TNS1","ATP8B2","CSGALNACT2","LOC100132247","NDUFA13","COL6A2",
                                                                          #"MORF4","APBB1","CWC22","EVC","MATR3","USP34","ARHGEF6","MSRB3","CADM3","LENG8","TPI1P3","ARFIP1","EFEMP2","GPRASP1","HSPG2","NKTR","RIF1","VIM","ZNF148","CNRIP1","MAP3K2","MGP","MPHOSPH10",
                                                                          #"POFUT1","RAB8B","UBA3","AGAP4","AKAP13","CDC27","DCUN1D1","DDX18","FBXW5","FERMT2","FRMD6","GNAO1","IFFO1","PHIP","SECISBP2L","SHROOM4","TRIB2","C13orf18","C5orf41","CLIP3","ITCH","MLL2",
                                                                          #"PTPRC","RAB31","SCRG1","TROVE2","ASXL2","BCLAF1","CD2AP","CREB1","JAM3","LOC440944","LOC91316","NDUFB5","PKN2","RNF43","RPL21","TYMP","ACTR2","CRIPT","CUL5","HEG1","MRVI1","NR2C2","SPDYE2",
                                                                          #"TIMP2","TNNC2","VAV3")]
#low_grade_colon_mRNA_standardize <- low_grade_colon_mRNA_standardize[,c("ZEB1","PCNP","CCDC80","ZNF638","BOC","AHSA2","PIKFYVE","C1S","OR7E37P","XPO1","AFF4","ZEB2","LY6G6D","SSB","VPS26A","SUMO1","TNS1","ATP8B2","CSGALNACT2","LOC100132247","NDUFA13","COL6A2",
                                                                        #"MORF4","APBB1","CWC22","EVC","MATR3","USP34","ARHGEF6","MSRB3","CADM3","LENG8","TPI1P3","ARFIP1","EFEMP2","GPRASP1","HSPG2","NKTR","RIF1","VIM","ZNF148","CNRIP1","MAP3K2","MGP","MPHOSPH10",
                                                                        #"POFUT1","RAB8B","UBA3","AGAP4","AKAP13","CDC27","DCUN1D1","DDX18","FBXW5","FERMT2","FRMD6","GNAO1","IFFO1","PHIP","SECISBP2L","SHROOM4","TRIB2","C13orf18","C5orf41","CLIP3","ITCH","MLL2",
                                                                        #"PTPRC","RAB31","SCRG1","TROVE2","ASXL2","BCLAF1","CD2AP","CREB1","JAM3","LOC440944","LOC91316","NDUFB5","PKN2","RNF43","RPL21","TYMP","ACTR2","CRIPT","CUL5","HEG1","MRVI1","NR2C2","SPDYE2",
                                                                        #"TIMP2","TNNC2","VAV3")]
########### network estimation 1 ##########
Sample_size <- 0.5*(dim(low_grade_colon_mRNA_standardize)[1]+dim(high_grade_colon_mRNA_standardize)[1])
nV <- dim(low_grade_colon_mRNA_standardize)[2]

ALPHA<-0.1
penalty_lambda<-round(2/Sample_size^0.5 *qnorm(ALPHA/2/nV^2, mean = 0, sd = 1, lower.tail = FALSE),5)
penalty_lambda_2<-penalty_lambda/2

# low grade
#low_grade_colon_mRNA_standardize <- as.matrix(low_grade_colon_mRNA_standardize)

#result_table <- matrix(NA,nrow=1,ncol=3)
#colnames(result_table) <- c("Y_gene","X_gene","coef")

#for(index in c(1:nV))
#{  
#  yy<-low_grade_colon_mRNA_standardize[,index]                   # Decide yy (child) and xx (parents) in the LASSO type penalized LR
#  xx<-low_grade_colon_mRNA_standardize[,-index]
  
#  y_node<-colnames(low_grade_colon_mRNA_standardize)[index] 
#  x_node<-colnames(low_grade_colon_mRNA_standardize)[-index]   
  
#  glmnet_fit<-glmnet(xx, yy,family=c("gaussian"),lambda=penalty_lambda_2)
#  inter_coef_list<-coef(glmnet_fit)
#  coef_list<-inter_coef_list[-1]
  
#  temp_TF <- coef_list!=0
#  selected_coef_list <- coef_list[temp_TF]
#  selected_x_node <- x_node[temp_TF]
  
#  if( length(selected_x_node)!=0 )
#  { 
#    temp_result_table <- cbind(y_node,selected_x_node,selected_coef_list) 
#    result_table <- rbind(result_table,temp_result_table)
#  }
#}   

#result_table_low_grade <- result_table[-1,]


# high grade
high_grade_colon_mRNA_standardize <- as.matrix(high_grade_colon_mRNA_standardize)

result_table <- matrix(NA,nrow=1,ncol=3)
colnames(result_table) <- c("Y_gene","X_gene","coef")

for(index in c(1:nV))
{  
  yy<-high_grade_colon_mRNA_standardize[,index]                   # Decide yy (child) and xx (parents) in the LASSO type penalized LR
  xx<-high_grade_colon_mRNA_standardize[,-index]
  
  y_node<-colnames(high_grade_colon_mRNA_standardize)[index] 
  x_node<-colnames(high_grade_colon_mRNA_standardize)[-index]   
  
  glmnet_fit<-glmnet(xx, yy,family=c("gaussian"),lambda=penalty_lambda_2)
  inter_coef_list<-coef(glmnet_fit)
  coef_list<-inter_coef_list[-1]
  
  temp_TF <- coef_list!=0
  selected_coef_list <- coef_list[temp_TF]
  selected_x_node <- x_node[temp_TF]
  
  if( length(selected_x_node)!=0 )
  { 
    temp_result_table <- cbind(y_node,selected_x_node,selected_coef_list) 
    result_table <- rbind(result_table,temp_result_table)
  }
  
}    

result_table_high_grade <- result_table[-1,]

write.csv(result_table_high_grade, "E:/20180907/clinical/network/positive_hub_network_sortnega/result_table_high_grade_lambda2_0.35114.csv")
#write.csv(result_table_low_grade, "C:/Users/mingming/Desktop/coloncancer/result_table_low_grade.csv")


########### network estimation 2 : lambda*0.5 ##########
Sample_size <- 0.5*(dim(low_grade_colon_mRNA_standardize)[1]+dim(high_grade_colon_mRNA_standardize)[1])
nV <- dim(low_grade_colon_mRNA_standardize)[2]

ALPHA<-0.1
penalty_lambda<-round(2/Sample_size^0.5 *qnorm(ALPHA/2/nV^2, mean = 0, sd = 1, lower.tail = FALSE),5)
penalty_lambda_2<-penalty_lambda/2
penalty_lambda_3<-penalty_lambda_2/2

# low grade
low_grade_colon_mRNA_standardize <- as.matrix(low_grade_colon_mRNA_standardize)

result_table <- matrix(NA,nrow=1,ncol=3)
colnames(result_table) <- c("Y_gene","X_gene","coef")

for(index in c(1:nV))
{  
  yy<-low_grade_colon_mRNA_standardize[,index]                   # Decide yy (child) and xx (parents) in the LASSO type penalized LR
  xx<-low_grade_colon_mRNA_standardize[,-index]
  
  y_node<-colnames(low_grade_colon_mRNA_standardize)[index] 
  x_node<-colnames(low_grade_colon_mRNA_standardize)[-index]   
  
  glmnet_fit<-glmnet(xx, yy,family=c("gaussian"),lambda=penalty_lambda_3)
  inter_coef_list<-coef(glmnet_fit)
  coef_list<-inter_coef_list[-1]
  
  temp_TF <- coef_list!=0
  selected_coef_list <- coef_list[temp_TF]
  selected_x_node <- x_node[temp_TF]
  
  if( length(selected_x_node)!=0 )
  { 
    temp_result_table <- cbind(y_node,selected_x_node,selected_coef_list) 
    result_table <- rbind(result_table,temp_result_table)
  }
}   

result_table_low_grade_lambda2 <- result_table[-1,]


# high grade
high_grade_colon_mRNA_standardize <- as.matrix(high_grade_colon_mRNA_standardize)

result_table <- matrix(NA,nrow=1,ncol=3)
colnames(result_table) <- c("Y_gene","X_gene","coef")

for(index in c(1:nV))
{  
  yy<-high_grade_colon_mRNA_standardize[,index]                   # Decide yy (child) and xx (parents) in the LASSO type penalized LR
  xx<-high_grade_colon_mRNA_standardize[,-index]
  
  y_node<-colnames(high_grade_colon_mRNA_standardize)[index] 
  x_node<-colnames(high_grade_colon_mRNA_standardize)[-index]   
  
  glmnet_fit<-glmnet(xx, yy,family=c("gaussian"),lambda=penalty_lambda_3)
  inter_coef_list<-coef(glmnet_fit)
  coef_list<-inter_coef_list[-1]
  
  temp_TF <- coef_list!=0
  selected_coef_list <- coef_list[temp_TF]
  selected_x_node <- x_node[temp_TF]
  
  if( length(selected_x_node)!=0 )
  { 
    temp_result_table <- cbind(y_node,selected_x_node,selected_coef_list) 
    result_table <- rbind(result_table,temp_result_table)
  }
  
}   

result_table_high_grade_lambda2 <- result_table[-1,]

write.csv(result_table_high_grade_lambda2, "C:/Users/mingming/Desktop/coloncancer/result_table_high_grade_lambda2.csv")
write.csv(result_table_low_grade_lambda2, "C:/Users/mingming/Desktop/coloncancer/result_table_low_grade_labmda2.csv")


########### network estimation 3 : lambda*0.25 ##########
Sample_size <- 0.5*(dim(low_grade_colon_mRNA_standardize)[1]+dim(high_grade_colon_mRNA_standardize)[1])
nV <- dim(low_grade_colon_mRNA_standardize)[2]

ALPHA<-0.1
penalty_lambda<-round(2/Sample_size^0.5 *qnorm(ALPHA/2/nV^2, mean = 0, sd = 1, lower.tail = FALSE),5)
penalty_lambda_2<-penalty_lambda/2
penalty_lambda_3<-penalty_lambda_2/2
penalty_lambda_4<-penalty_lambda_3/2

# low grade
low_grade_colon_mRNA_standardize <- as.matrix(low_grade_colon_mRNA_standardize)

result_table <- matrix(NA,nrow=1,ncol=3)
colnames(result_table) <- c("Y_gene","X_gene","coef")

for(index in c(1:nV))
{  
  yy<-low_grade_colon_mRNA_standardize[,index]                   # Decide yy (child) and xx (parents) in the LASSO type penalized LR
  xx<-low_grade_colon_mRNA_standardize[,-index]
  
  y_node<-colnames(low_grade_colon_mRNA_standardize)[index] 
  x_node<-colnames(low_grade_colon_mRNA_standardize)[-index]   
  
  glmnet_fit<-glmnet(xx, yy,family=c("gaussian"),lambda=penalty_lambda_4)
  inter_coef_list<-coef(glmnet_fit)
  coef_list<-inter_coef_list[-1]
  
  temp_TF <- coef_list!=0
  selected_coef_list <- coef_list[temp_TF]
  selected_x_node <- x_node[temp_TF]
  
  if( length(selected_x_node)!=0 )
  { 
    temp_result_table <- cbind(y_node,selected_x_node,selected_coef_list) 
    result_table <- rbind(result_table,temp_result_table)
  }
}   

result_table_low_grade_lambda4 <- result_table[-1,]


# high grade
high_grade_colon_mRNA_standardize <- as.matrix(high_grade_colon_mRNA_standardize)

result_table <- matrix(NA,nrow=1,ncol=3)
colnames(result_table) <- c("Y_gene","X_gene","coef")

for(index in c(1:nV))
{  
  yy<-high_grade_colon_mRNA_standardize[,index]                   # Decide yy (child) and xx (parents) in the LASSO type penalized LR
  xx<-high_grade_colon_mRNA_standardize[,-index]
  
  y_node<-colnames(high_grade_colon_mRNA_standardize)[index] 
  x_node<-colnames(high_grade_colon_mRNA_standardize)[-index]   
  
  glmnet_fit<-glmnet(xx, yy,family=c("gaussian"),lambda=penalty_lambda_4)
  inter_coef_list<-coef(glmnet_fit)
  coef_list<-inter_coef_list[-1]
  
  temp_TF <- coef_list!=0
  selected_coef_list <- coef_list[temp_TF]
  selected_x_node <- x_node[temp_TF]
  
  if( length(selected_x_node)!=0 )
  { 
    temp_result_table <- cbind(y_node,selected_x_node,selected_coef_list) 
    result_table <- rbind(result_table,temp_result_table)
  }
  
}   

result_table_high_grade_lambda4 <- result_table[-1,]

write.csv(result_table_high_grade_lambda4, "C:/Users/mingming/Desktop/coloncancer/result_table_high_grade_lambda4.csv")
write.csv(result_table_low_grade_lambda4, "C:/Users/mingming/Desktop/coloncancer/result_table_low_grade_labmda4.csv")

########��ó��####
rm(list=ls())
d <- read.csv("E:/20180907/clinical/combined_data.csv",header=TRUE,sep=",")
a <- read.csv("E:/20180907/clinical/COAD_combined_data.csv",header=TRUE,sep=",")
colnames(a)
colnames(d[1:3])
a <- a[,c(1:20)]

c <- cbind(a,d)
colnames(c)
write.csv(c, "E:/20180907/clinical/combined_data.csv",row.names=F)


rm(list=ls())
high <- read.csv("E:/high_grade_colon_mRNA.csv")
low <-read.csv("E:/low_grade_colon_mRNA.csv")

head(c[1:20])
high[1,]
b<-high[-c(2,17,20,29,50,89,107,178,179),]
a<-high[c(2,17,20,29,50,89,107,178,179),]
a[1:3]
c <-rbind(a,low)
write.csv(b, "E:/20180907/clinical/high_grade_colon_mRNA.csv",row.names=F)
write.csv(c, "E:/20180907/clinical/low_grade_colon_mRNA.csv",row.names=F)