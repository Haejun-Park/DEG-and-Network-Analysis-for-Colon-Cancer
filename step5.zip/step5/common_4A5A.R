

rm(list=ls())
#library(readxl)
library(network)
library(sqldf)


low <- read.csv("E:/20180907/clinical/network/negative_hub_network_sortnega/hub_exist_low_grade_lambda2_0.35114.csv")
high <- read.csv("E:/20180907/clinical/network/positive_hub_network_sortposi/hub_exist_high_grade_lambda2_0.34027.csv")

ID.low <- as.character(low[,1])
ID.high <-as.character(high[,1])

match.index <- match(ID.high, ID.low)
match.index1 <- match(ID.low,ID.high)

low_data <- low[match.index,]
high_data <- high[match.index1,]

file_name_combined_data =paste("E:/20180907/clinical/network/negative_hub_network_sortnega/hub_sortbypositive_negative_data_5-A.csv", sep="")
write.table(low_data ,row.names=FALSE,col.names=TRUE, file=file_name_combined_data ,sep=",")

file_name_combined_data =paste("E:/20180907/clinical/network/positive_hub_network_sortposi/hub_sortbynegative_positive_data_4-A.csv", sep="")
write.table(high_data ,row.names=FALSE,col.names=TRUE, file=file_name_combined_data ,sep=",")



#########positive posisort 
rm(list=ls())
library(network)
library(sqldf)
name_index <- c( "supp 1" )
#normal_lambda <- c( 0.31431 )


high_list <- as.data.frame(read.csv("E:/20180907/clinical/network/exist/high_low_list.csv"))
info_du <- as.data.frame(read.csv("E:/20180907/clinical/network/exist/positive_4A/SSB.csv"))

file_name=paste("E:/20180907/clinical/network/positive_hub_network_sortposi/result_table_high_grade_lambda2_0.34027.csv")
result_table<-as.matrix(read.table(file_name, header=FALSE, sep=",")) 
file_name=paste("E:/20180907/clinical/network/positive_hub_network_sortposi/hub_exist_high_grade_lambda2_0.34027.csv")
hub_gene <- as.data.frame(read.table(file_name, header=TRUE, sep=","))

hub_gene$degree <- as.numeric(hub_gene$degree)
#hub_gene <- hub_gene[c(order(-hub_gene$degree)),]
rownames(hub_gene) <- NULL
View(hub_gene[1:200,1])
gene_top <- hub_gene[31,1] #top 10
#gene_top
for(i in gene_top){
  #i
  result_table_c <- result_table[result_table[,1] %in% i | result_table[,2] %in% i,]  
  #result_table_c
  b <- as.vector(unique(rbind(as.matrix(unique(result_table_c[,1])), as.matrix(unique(result_table_c[,2])))))
  c <- length(b) 
  true_c<-matrix(rep(0, c*c), c, c)
  
  colnames(true_c) <- b
  rownames(true_c) <- b
  
  node_info <- as.data.frame(b)
  colnames(node_info) <- c("name")
  node_info <- sqldf('SELECT a.name, b.type
                     FROM node_info a
                     LEFT JOIN high_list b USING(name)')
  
  #edge_info_un <- as.data.frame(b)
  #colnames(edge_info_un) <- c("name")
  #edge_info_un <- sqldf('SELECT c.name, d.type 
  #FROM edge_info_un c 
  #LEFT JOIN info_un d USING(name)')
  
  edge_info_du <- as.data.frame(b)
  colnames(edge_info_du) <- c("name")
  edge_info_du <- sqldf('SELECT e.name, f.type 
                        FROM edge_info_du e 
                        LEFT JOIN info_du f USING(name)')
  
  for(j in 1:dim(result_table_c)[1])
  {
    true_c[result_table_c[j,1], result_table_c[j,2]] <- result_table_c[j,3]
  }
  
  true_X<-true_c
  true_X[true_X!=0]<-1
  
  d<-as.numeric(result_table_c[,3])
  
  
  aa1 <- network(true_X)
  
  
  file_name=paste("E:/20180907/clinical/network/exist/positive_4A/supp1_high_",i,".png", sep="")
  png(filename=file_name, height=1000, width=1000, bg="white")
  plot(aa1,displaylabels=TRUE,
       boxed.labels=FALSE,
       arrowhead.cex=0,
       #label.cex= ifelse(is.na(edge_info_du$type),1.3,
       #ifelse(edge_info_du$type=="b",4,1.3)), #character expansion factor for label text,
       #label.lwd = ifelse(edge_info_du$type == "b", 10 , 0),
       pad=0.25,
       label.pos=10,
       edge.lwd=d*3.5,
       vertex.cex=2.5,
       #vertex.cex= ifelse(is.na(edge_info_un$type) ,2.5,
       #ifelse(edge_info_un$type == "a",2.5,2.5)), #expansion factor for vertices
       #edge.col = ifelse(is.na(edge_info_du$type),"black",
       #ifelse(edge_info_du$type=="b","dark red","black")),
       label.col = ifelse(is.na(edge_info_du$type),"black",
                          ifelse(edge_info_du$type == "b","dark red","black")),
       #vertex.enclose = ifelse(is.na(edge_info_un$type),FALSE,
       #ifelse(edge_info_un$type=="a",TRUE,FALSE)),
       vertex.col =  ifelse(is.na(node_info$type),"white",
                            ifelse(node_info$type == "up", "light pink", "light green")),
       
       mode ="fruchtermanreingold",  # "kamadakawai",  #"circle", #"fruchtermanreingold", 
       cex.main=3)
  
  dev.off()
}


####################


rm(list=ls())
#library(readxl)
library(network)
library(sqldf)

#low <- read.csv("E:/20180907/clinical/network/negative_hub_network_sortposi/hub_exist_low_grade_lambda2_0.34027.csv")
#high <- read.csv("E:/20180907/clinical/network/positive_hub_network_sortposi/hub_exist_high_grade_lambda2_0.34027.csv")

#ID.low <- as.character(low[,1])
#ID.high <-as.character(high[,1])

#match.index <- match(ID.high, ID.low)
#match.index1 <- match(ID.low,ID.high)

#low_data <- low[match.index,]
#high_data <- high[match.index1,]

#file_name_combined_data =paste("E:/20180907/clinical/network/negative_hub_network_sortposi/hub_sortbypositive_negative_data.csv", sep="")
#write.table(low_data ,row.names=FALSE,col.names=TRUE, file=file_name_combined_data ,sep=",")

#file_name_combined_data =paste("E:/20180907/network/exist/sortbynegative_positive_data.csv", sep="")
#write.table(high_data ,row.names=FALSE,col.names=TRUE, file=file_name_combined_data ,sep=",")


##########negative negasort
rm(list=ls())
library(network)
library(sqldf)

name_index <- c( "supp 1" )
#normal_lambda <- c( 0.31431 )


high_list <- as.data.frame(read.csv("E:/20180907/clinical/network/exist/high_low_list.csv"))
info_du <- as.data.frame(read.csv("E:/20180907/clinical/network/exist/positive_4A/VPS26A.csv"))

file_name=paste("E:/20180907/clinical/network/negative_hub_network_sortnega/result_table_low_grade_lambda2_0.35114.csv")
result_table<-as.matrix(read.table(file_name, header=FALSE, sep=",")) 
file_name=paste("E:/20180907/clinical/network/negative_hub_network_sortnega/hub_exist_low_grade_lambda2_0.35114.csv")
hub_gene <- as.data.frame(read.table(file_name, header=TRUE, sep=","))

hub_gene$degree <- as.numeric(hub_gene$degree)
#hub_gene <- hub_gene[c(order(-hub_gene$degree)),]
rownames(hub_gene) <- NULL
View(hub_gene[1:200,1])
gene_top <- hub_gene[7,1] #top 10
#gene_top
for(i in gene_top){
  #i
  result_table_c <- result_table[result_table[,1] %in% i | result_table[,2] %in% i,]  
  #result_table_c
  b <- as.vector(unique(rbind(as.matrix(unique(result_table_c[,1])), as.matrix(unique(result_table_c[,2])))))
  c <- length(b) 
  true_c<-matrix(rep(0, c*c), c, c)
  
  colnames(true_c) <- b
  rownames(true_c) <- b
  
  node_info <- as.data.frame(b)
  colnames(node_info) <- c("name")
  node_info <- sqldf('SELECT a.name, b.type
                     FROM node_info a
                     LEFT JOIN high_list b USING(name)')
  
  #edge_info_un <- as.data.frame(b)
  #colnames(edge_info_un) <- c("name")
  #edge_info_un <- sqldf('SELECT c.name, d.type 
  #FROM edge_info_un c 
  #LEFT JOIN info_un d USING(name)')
  
  edge_info_du <- as.data.frame(b)
  colnames(edge_info_du) <- c("name")
  edge_info_du <- sqldf('SELECT e.name, f.type 
                        FROM edge_info_du e 
                        LEFT JOIN info_du f USING(name)')
  
  for(j in 1:dim(result_table_c)[1])
  {
    true_c[result_table_c[j,1], result_table_c[j,2]] <- result_table_c[j,3]
  }
  
  true_X<-true_c
  true_X[true_X!=0]<-1
  
  d<-as.numeric(result_table_c[,3])
  
  
  aa1 <- network(true_X)
  
  
  file_name=paste("E:/20180907/clinical/network/exist/negative_5A/supp1_hub_nega_",i,".png", sep="")
  png(filename=file_name, height=1000, width=1000, bg="white")
  plot(aa1,displaylabels=TRUE,
       boxed.labels=FALSE,
       arrowhead.cex=0,
       #label.cex= ifelse(is.na(edge_info_du$type),1.3,
       #ifelse(edge_info_du$type=="b",4,1.3)), #character expansion factor for label text,
       #label.lwd = ifelse(edge_info_du$type == "b", 10 , 0),
       pad=0.25,
       label.pos=10,
       edge.lwd=d*3.5,
       vertex.cex=2.5,
       #vertex.cex= ifelse(is.na(edge_info_un$type) ,2.5,
       #ifelse(edge_info_un$type == "a",2.5,2.5)), #expansion factor for vertices
       #edge.col = ifelse(is.na(edge_info_du$type),"black",
       #ifelse(edge_info_du$type=="b","dark red","black")),
       label.col = ifelse(is.na(edge_info_du$type),"black",
                          ifelse(edge_info_du$type == "b","dark red","black")),
       #vertex.enclose = ifelse(is.na(edge_info_un$type),FALSE,
       #ifelse(edge_info_un$type=="a",TRUE,FALSE)),
       vertex.col =  ifelse(is.na(node_info$type),"white",
                            ifelse(node_info$type == "up", "light green", "light pink")),
       
       mode ="fruchtermanreingold",  # "kamadakawai",  #"circle", #"fruchtermanreingold", 
       cex.main=3)
  
  dev.off()
}
